import AdminLoginForm from "../../../component/admin-panel-components/admin-login.component";

const Adminlogin = () => {

  return (
    <div>
      <AdminLoginForm />
    </div>
  );
};
  
  export default Adminlogin;